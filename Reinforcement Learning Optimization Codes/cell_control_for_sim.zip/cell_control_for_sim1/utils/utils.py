import os
import numpy as np
import copy


class BiDict:
    def __init__(self, d):
        if isinstance(d, dict):
            assert len(set(d.values())) == len(d)

            self.fw = copy.deepcopy(d)
            self.bw = {self.fw[k]:k for k in self.fw}
        elif isinstance(d, list):
            self.fw = copy.deepcopy(d)
            self.bw = {self.fw[i]:i for i in range(len(self.fw))}
        else:
            raise NotImplementedError

class Loader:
    def __init__(self):
        self.data = {}

    def load(self, filename, update=False):
        if filename not in self.data or update:
            self.data[filename] = np.load(filename, allow_pickle=True)[()]
        return self.data[filename]

    def delete(self, filename):
        if filename in self.data:
            del self.data[filename]

class RunningCriteria:
    def __init__(self, keys:list, running_lengths:list):
        self.data = {k:[] for k in keys}
        self.running_lengths = running_lengths

    def add(self, keys, items):
        for k, item in zip(keys, items):
            self.data[k].append(item)

    def _get_running_value(self, values:list, length):
        length = min(length, len(values))
        if isinstance(values[0], dict) or isinstance(values[0], list):
            return None
        return sum(values[-length:]) / max(1e-6, length)

    def eval(self):
        return {k:{l:self._get_running_value(self.data[k], l) for l in self.running_lengths} for k in self.data}

    def save(self, path, name):
        if not os.path.exists(path):
            os.makedirs(path)
        np.save('{}/{}.npy'.format(path, name), self.data)

    def load(self, path, name):
        self.data = np.load('{}/{}.npy'.format(path, name), allow_pickle=True)[()]

def dict_to_array(d:dict, keys:list):
    """

    :param d:       {k1:v1, k2:v2, ...}
    :param keys:    [k1,k2,...]
    :return:        [v1, v2, ...]
    """
    result = np.array([d[k] for k in keys]).astype('float32')

    return result

def concatenate_feature(features):
    assert np.array(len(f.shape)==1 for f in features).all()
    feature = np.concatenate([f[:, None] for f in features], axis=1)

    return feature


