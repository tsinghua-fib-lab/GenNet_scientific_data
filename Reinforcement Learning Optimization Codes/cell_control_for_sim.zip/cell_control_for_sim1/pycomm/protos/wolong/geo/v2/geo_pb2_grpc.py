
'Client and server classes corresponding to protobuf-defined services.'
import grpc
