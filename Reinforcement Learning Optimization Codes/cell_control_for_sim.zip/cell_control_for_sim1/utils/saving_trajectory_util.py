import os
import json
import numpy as np

class TrajectoryStorage:
    def __init__(self, path, n_start=0):
        self.path = path
        self.n_iter = n_start

        if not os.path.exists(path):
            os.mkdir(path)

    def store_transition(self, sample):
        filename = '{}/{}.json'.format(self.path, self.n_iter)
        with open(filename, 'w') as f:
            json.dump(sample, f)

        self.n_iter += 1


if __name__ == '__main__':
    store = TrajectoryStorage('temp.json')

    store.store_transition({'state': {1:2},
                            'action': [1,2],
                            'reward': 2.})

    store.store_transition({'state': {3:4},
                            'action': [3,4],
                            'reward': 5.})