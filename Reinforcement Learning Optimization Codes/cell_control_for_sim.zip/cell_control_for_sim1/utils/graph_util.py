import numpy as np

class BipartiteGraph:
    def __init__(self, pairs, values=None):
        """

        :param pairs:       the edges e=(node_i,node_j)
        :param values:      the values of the edges
        """
        self.pairs = pairs
        self.values = values if values is not None else np.zeros([len(pairs)])
        self.pair_value = {pair:value for pair, value in zip(self.pairs, self.values.tolist())}

        self.nodes_left = set(p[0] for p in pairs)
        self.nodes_right = set(p[1] for p in pairs)
        self.n_left, self.n_right = len(self.nodes_left), len(self.nodes_right)

        self.nodes_from = {node:[] for node in self.nodes_left}
        self.nodes_to = {node: [] for node in self.nodes_right}
        for p in self.pairs:
            self.nodes_from[p[0]].append(p[1])
            self.nodes_to[p[1]].append(p[0])
