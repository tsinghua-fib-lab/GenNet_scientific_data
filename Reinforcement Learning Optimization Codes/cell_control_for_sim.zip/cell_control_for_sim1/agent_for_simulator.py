import json
import os
import copy
import time
from enum import Enum
import numpy as np
import torch
import torch.nn as nn
import dgl
from moudles.encoder import create_from_heterogeneous_graph
from utils.network_util import weight_init
from utils.utils import RunningCriteria
from utils.saving_trajectory_util import TrajectoryStorage
from utils.time_util import RemainingTime
import setproctitle
from utils.graph_util import BipartiteGraph
from utils.utils import BiDict
from pycomm import ConserveEnv
start_time, final_time = 25200, 43200

class SimulatorCellControlState(Enum):
    UNSPECIFIED = 0
    OPEN = 1
    SLEEP = 2
    OFF = 3

class CellActivateStatus(Enum):
    ACTIVATE = 0
    DEACTIVATE = 1

class SimulatorBaseStationControlState(Enum):
    UNSPECIFIED = 0
    OPEN = 1
    OFF = 2

class InterfaceToSimulator:
    def __init__(self, interface=None, start = start_time,total = 5,interval = 1):
        self.interface = interface
        # self.start = start
        self.start = np.random.randint(low=0, high=(final_time-start_time)/5) * 5 + start_time  # [start_time-final_time]
        self.total = total
        self.interval = interval

        # hyperparameter
        self.demand_feature_scale = 1. / np.array([1.e4])
        self.cell_feature_scale = 1. / np.array((1.e-3, 1.e3, 1.e4, 1.))
        self.bs_feature_scale = 1. / np.array((1.e2, 1.))
        self.enough_larger_value = 1.e6

        # transition recorder
        self.transition_recorder = {}

        self._generate_example()

    def _generate_example(self):
        # ---- example state
        # number
        self.n_bs = 2
        self.n_cell = 2
        self.n_user = 4
        # ids
        self.bs_key_ids = [101, 111]
        self.bs_ids = list(range(len(self.bs_key_ids)))
        self.bs_id_to_kid = BiDict(self.bs_key_ids)
        self.cell_ids = [0, 1]
        self.user_key_ids = [10, 11, 102, 31]
        self.user_ids = list(range(len(self.user_key_ids)))
        self.user_id_to_kid = BiDict(self.user_key_ids)
        # graph
        self.bigraph_user_cell = BipartiteGraph([(0, 0), (1, 0), (2, 0), (1, 1), (2, 1), (3, 1)])
        self.bigraph_cell_bs = BipartiteGraph([(0, 0), (1, 1)])
        # power coef
        self.bbu_power = np.ones([self.n_bs])
        self.cell_sleep_power = np.ones([self.n_cell])
        self.cell_power_coef = np.ones([self.n_cell, 2])
        self.air_condition_power_coef = np.ones([self.n_bs, 2])
        # capacity
        self.capacity = np.ones([self.n_cell]) * 4
        # demand
        self.user_demand = {0:1., 1:1., 2:1., 3:1.}

        # ---- example action
        # [(bs_id,bs_state)]
        self.bs_control_state = np.ones([self.n_bs]) * SimulatorBaseStationControlState.OPEN.value
        self.cell_control_state = np.ones([self.n_cell]) * SimulatorCellControlState.OPEN.value
        self.traffic = {(0,0): 1., (0,1): 1., (0,2): 1., (3,1): 1.}

        # ---- example reward
        self.sim_info = {
            'criteria':{'power_save_ratio': 0.5}
        }

    def _to_graph(self):
        # get graph
        dcc_edges = np.array(self.bigraph_user_cell.pairs).astype('int32')
        cb_edges = np.array(self.bigraph_cell_bs.pairs).astype('int32')
        graph_data = {
            ('demand', 'covered', 'cell'): (torch.tensor(dcc_edges[:, 0]), torch.tensor(dcc_edges[:, 1])),
            ('cell', 'cover', 'demand'): (torch.tensor(dcc_edges[:, 1]), torch.tensor(dcc_edges[:, 0])),
            ('cell', 'belong', 'bs'): (torch.tensor(cb_edges[:, 0]), torch.tensor(cb_edges[:, 1])),
            ('bs', 'contain', 'cell'): (torch.tensor(cb_edges[:, 1]), torch.tensor(cb_edges[:, 0])),
        }
        graph = dgl.heterograph(graph_data)

        # get node features
        graph.nodes['demand'].data['feature'] = \
            torch.Tensor([[self.user_demand[uid]] for uid in self.user_ids]) \
            * torch.Tensor(self.demand_feature_scale[:1])  # [n_cell, 1]
        print('demand max', max(list(self.user_demand.values())))
        graph.nodes['cell'].data['feature'] = \
            torch.Tensor(np.concatenate([
                self.cell_power_coef,
                self.capacity[:, None]], axis=-1)) \
            * torch.Tensor(self.cell_feature_scale[:3])  # [n_cell, 3]
        print('cell_power_coef max', self.cell_power_coef.max(axis=0))
        print('self.capacity max', self.capacity.max())
        graph.nodes['bs'].data['feature'] = \
            torch.Tensor(self.bbu_power).unsqueeze(-1) \
            * torch.Tensor(self.bs_feature_scale[:1])  # [n_cell, 1]
        print('self.bbu_power max', self.bbu_power.max())
        return graph

    def _update_state(self, state_info): #把模拟器传回来的 state 转为example中的对应格式并记录下来。
        # num
        self.n_bs = state_info['bs_num']
        self.n_cell = state_info['cell_num']
        self.n_user = len(state_info['demand'])
        # user ids
        self.user_key_ids = [i['user_id'] for i in state_info['demand']]
        self.user_ids = list(range(len(self.user_key_ids)))
        self.user_id_to_kid = BiDict(self.user_key_ids)
        # bs ids
        self.bs_key_ids = [i[0] for i in state_info['bigraph_cell_bs']]
        self.bs_ids = list(range(len(self.bs_key_ids)))
        self.bs_id_to_kid = BiDict(self.bs_key_ids)

        # user demand
        self.user_demand = {self.user_id_to_kid.bw[i['user_id']]: i['demand'] for i in state_info['demand']}
        # bigraph
        user_key_ids = {i:None for i in self.user_key_ids}
        bs_key_ids = {i:None for i in self.bs_key_ids}
        self.bigraph_user_cell = BipartiteGraph([(self.user_id_to_kid.bw[i[0]], self.bs_id_to_kid.bw[i[1]])
                                                 for i in state_info['bigraph_demand_cell']
                                                 if i[0] in user_key_ids and i[1] in bs_key_ids])
        self.bigraph_cell_bs = BipartiteGraph([(self.bs_id_to_kid.bw[i[0]], self.bs_id_to_kid.bw[i[1]])
                                               for i in state_info['bigraph_cell_bs']])
        # bs cell features
        self.bbu_power = np.array(state_info['bbu_power'])
        self.cell_sleep_power = np.array(state_info['cell_sleep_power'])
        self.cell_power_coef = np.array(state_info['cell_power_coef'])
        self.air_condition_power_coef = np.array(state_info['air_condition_power_coef'])
        self.capacity = np.array(state_info['cell_capacity'])


    def _update_sim_info(self, action):
        # _t = time.time()
        print('self.start', self.start)
        async_coroutine_step, terminated, _ = \
            self.interface.step(action, self.start, self.total, self.interval)
        state, reward = async_coroutine_step
        self.sim_info = {'criteria': reward }
        # self.start = (self.start + self.total if self.start + self.total < final_time else start_time)
        self.start = np.random.randint(low=0, high=(final_time - start_time) / 5) * 5 + start_time  # [start_time-final_time]
        # print('_update_sim_info', time.time()-_t)

    def get_state(self):
        if self.interface is not None:
            print('self.start', self.start)
            info = self.interface.step({"traffic": {}, "bs_actions": [], "cell_actions": []},
                                       self.start, self.total, self.interval)
            state_info, _ = info[0]
            state_info['bbu_power'] = list(state_info['bbu_power'])
            state_info['cell_sleep_power'] = list(state_info['cell_sleep_power'])
            state_info['cell_capacity'] = list(state_info['cell_capacity'])
            # _t = time.time()
            self._update_state(state_info)
            # print('self._update_state(state_info)', time.time() - _t)
        return self._to_graph(), state_info

    def _check_action(self):
        pass

    def _get_traffic_heuristic(self, cell_activate_status):
        slope = self.cell_power_coef[:, 0] \
                + self.enough_larger_value * (cell_activate_status==CellActivateStatus.DEACTIVATE.value)
        sort_idx = np.argsort(slope)

        traffic = {}
        miss_traffic = 0.
        cell_activate_status = np.ones_like(cell_activate_status)
        remaining_capacity = np.copy(self.capacity)
        user_demand = copy.deepcopy(self.user_demand)
        for i in sort_idx:
            for j in self.bigraph_user_cell.nodes_to[i]:
                if j in user_demand and user_demand[j] < remaining_capacity[i]:
                    traffic[(j,i)] = user_demand[j]

                    remaining_capacity[i] -= user_demand[j]
                    del user_demand[j]

                    cell_activate_status[i] = CellActivateStatus.ACTIVATE.value
        miss_traffic = sum(user_demand.values())
        return miss_traffic, traffic, cell_activate_status

    def sim_action(self, action=None):
        miss_traffic, traffic, cell_activate_status = self._get_traffic_heuristic(action['cell_activate_status'])
        cell_control_state = \
            [SimulatorCellControlState.OPEN.value if a == CellActivateStatus.ACTIVATE.value
             else SimulatorCellControlState.OFF.value
             for a in cell_activate_status]
        bs_control_state = \
            [SimulatorBaseStationControlState.OPEN.value if a == CellActivateStatus.ACTIVATE.value
             else SimulatorBaseStationControlState.OFF.value
             for a in cell_activate_status]

        action = {}
        traffic_info = []
        for (u, c), v in traffic.items():
            traffic_info.append({'user_id': self.user_id_to_kid.fw[u], 'cell_id': self.bs_id_to_kid.fw[c], 'traffic': v})
        action['traffic'] = traffic_info
        action['bs_actions'] = [(self.bs_id_to_kid.fw[i], v) for i, v in enumerate(bs_control_state)]
        action['cell_actions'] = [(self.bs_id_to_kid.fw[i], v) for i, v in enumerate(cell_control_state)]

        self._update_sim_info(action)
        self.sim_info['miss_traffic'] = miss_traffic

        return self.sim_info, action

class RolloutBuffer:
    def __init__(self):
        self.actions = []
        self.states = []
        self.values = []
        self.logprobs = []
        self.rewards = []
        self.dones = []

    def sample_batch(self, n_batch):
        idx = np.random.randint(0, len(self.actions), n_batch)
        s = self.states[idx]
        v = self.values[idx]
        a = self.actions[idx]
        lp = self.logprobs[idx]
        r = self.rewards[idx]
        d = self.dones[idx]
        return s, v, a, lp, r, d

    def to_array(self):
        self.states = np.array(self.states)
        self.values = np.array(self.values)
        self.actions = np.array(self.actions)
        self.logprobs = np.array(self.logprobs)
        self.rewards = np.array(self.rewards)
        self.dones = np.array(self.dones)

    def clear(self):
        del self.actions
        del self.states
        del self.values
        del self.logprobs
        del self.rewards
        del self.dones
        self.actions = []
        self.states = []
        self.values = []
        self.logprobs = []
        self.rewards = []
        self.dones = []

class GraphMAPPOAgent:
    def __init__(self, example_graph_state, selected_node_type, data_key, n_episode_length, n_reward, device='cuda:0'):
        self.class_initializing_time = time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime())

        # ---- hyper-parameters
        # graph
        self.data_key = data_key
        # graph network
        self.n_graph_hidden = 8
        self.n_head = 6
        self.n_layer = 2
        # policy and value network
        self.n_policy_hidden = 16
        # optim
        self.learning_rate = 1e-3
        # env
        self.n_episode_length = n_episode_length
        self.n_reward = n_reward
        # ppo
        self.gamma = 0.99
        self.eps_clip = 0.2
        self.n_batch = 1
        self.update_each_n_timestep = self.n_batch * self.n_episode_length * 16
        self.n_epoch_each_update = int(self.update_each_n_timestep * 5 / self.n_batch)
        # save
        self.n_epoch = 0
        self.save_each_n_epoch = 1000 * self.n_epoch_each_update

        # ---- buffer
        self.buffer = RolloutBuffer()

        # ---- network
        self.device = device
        self.encoder = create_from_heterogeneous_graph(
            example_graph_state, data_key=self.data_key,
            n_hidden=self.n_graph_hidden, n_out=self.n_policy_hidden, n_head=self.n_head, n_layer=self.n_layer,
            device=device)
        self.selected_node_type = selected_node_type

        self.policy_layers = nn.Sequential(
            nn.LeakyReLU(),
            nn.Linear(self.n_policy_hidden, self.n_policy_hidden),
            nn.LeakyReLU(),
            nn.Linear(self.n_policy_hidden, 1),
        )
        self.value_layers = nn.Sequential(
            nn.LeakyReLU(),
            nn.Linear(self.n_policy_hidden, self.n_policy_hidden),
            nn.LeakyReLU(),
            nn.Linear(self.n_policy_hidden, self.n_reward),
        )
        self.policy_layers.apply(weight_init)
        self.value_layers.apply(weight_init)
        self.policy_layers.to(self.device)
        self.value_layers.to(self.device)

        # ---- optim
        self.optim = torch.optim.Adam(list(self.encoder.parameters())
                                      +list(self.policy_layers.parameters())
                                      +list(self.value_layers.parameters()),
                                      lr=self.learning_rate, betas=(0.99, 0.999))

    def update_env_episode_length(self, n_episode_length):
        # env
        self.n_episode_length = n_episode_length
        # ppo
        self.update_each_n_timestep = 32 * self.n_episode_length
        self.n_epoch_each_update = int(self.update_each_n_timestep * 1 / self.n_batch)
        # save
        self.save_each_n_epoch = 1000 * self.n_epoch_each_update

    def _cal_action_logit(self, graph_state):
        # encode to logit
        encode = self.encoder(graph_state, self.data_key)
        x = encode[self.selected_node_type]  # [n_cell, n_hid]
        logit = self.policy_layers(x).squeeze(-1)  # [n_cell]

        return logit

    def sample_action(self, graph_state):
        with torch.no_grad():
            encode = self.encoder(graph_state, self.data_key)
            x = encode[self.selected_node_type]  # [n_cell, n_hid]
            logit = self.policy_layers(x).squeeze(-1)  # [n_cell]
            x1 = torch.mean(x, dim=0)  # [n_hid]
            state_value = self.value_layers(x1)  # [n_reward]

            # sample action
            action_dist = torch.distributions.bernoulli.Bernoulli(logits=logit)
            action = action_dist.sample()
            action_logprob = action_dist.log_prob(action)

            return action, action_logprob, state_value

    def _eval(self, graph_state, action):
        # encode to logit and value
        encode = self.encoder(graph_state, self.data_key)
        batch_num_nodes = graph_state.batch_num_nodes(self.selected_node_type)
        list_action_logprob, list_state_value, list_dist_entropy = [], [], []
        for i in range(self.n_batch):
            idx_b, idx_e = batch_num_nodes[:i].sum(), batch_num_nodes[:i+1].sum()
            x = encode[self.selected_node_type][idx_b:idx_e] # [n_cell, n_hid]
            logit = self.policy_layers(x).squeeze(-1) # [n_cell]
            x1 = torch.mean(x, dim=0) # [n_hid]
            state_value = self.value_layers(x1) # [n_reward]

            action_dist = torch.distributions.bernoulli.Bernoulli(logits=logit)
            action_logprob = action_dist.log_prob(action[idx_b:idx_e]) # [1]
            dist_entropy = action_dist.entropy() # [1]

            list_state_value.append(state_value)
            list_action_logprob.append(action_logprob)
            list_dist_entropy.append(dist_entropy)

        # action_logprob = torch.stack(list_action_logprob)
        # state_value = torch.stack(list_state_value)
        # dist_entropy = torch.stack(list_dist_entropy)
        return list_action_logprob, list_state_value, list_dist_entropy

    def update(self):
        if len(self.buffer.states) < self.update_each_n_timestep:
            return

        # Monte Carlo estimate of returns
        rewards = []
        discounted_reward = np.zeros(self.n_reward)
        for reward, value, done in zip(reversed(self.buffer.rewards), reversed(self.buffer.values), reversed(self.buffer.dones)):
            if done:
                discounted_reward = np.zeros(self.n_reward)
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)

            discounted_reward = value
        self.buffer.rewards = rewards
        self.buffer.to_array()

        # Optimize policy for K epochs
        for _ in range(self.n_epoch_each_update):
            s, _, a, lp, r, _ = self.buffer.sample_batch(self.n_batch)

            with torch.no_grad():
                states = dgl.batch(s).to(self.device)
                actions = torch.tensor(np.concatenate(a)).to(self.device)
                old_logprobs = torch.tensor(np.concatenate(lp)).to(self.device)
                rewards = torch.tensor(np.concatenate(r)).to(self.device)

            # Evaluating old actions and values
            list_action_logprob, list_state_value, list_dist_entropy = self._eval(states, actions)

            loss = 0.
            idx_b, idx_e = 0, 0
            for logprob, state_value, dist_entropy, reward \
                    in zip(list_action_logprob, list_state_value, list_dist_entropy, rewards):
                idx_e += logprob.shape[0]
                old_logprob = old_logprobs[idx_b:idx_e].detach()

                # Finding the ratio (pi_theta / pi_theta__old)
                ratios = torch.exp(logprob - old_logprob)

                # Finding Surrogate Loss
                advantages = (reward - state_value).sum(-1).detach()
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages

                # final loss of clipped objective PPO
                loss += -torch.min(surr1, surr2).sum() + 0.5 * ((state_value - reward) ** 2.).sum(-1) - 0.001 * dist_entropy.sum()

                idx_b += logprob.shape[0]
            loss /= self.n_batch
            print('policy_loss', -torch.min(surr1, surr2).mean().item(),
                  'value_loss', ((state_value - rewards) ** 2.).sum(-1).mean().item(),
                  'entropy', -dist_entropy.mean().item())

            # take gradient step
            self.optim.zero_grad()
            loss.backward()
            self.optim.step()
        # clear buffer
        self.buffer.clear()

        # record num of epoch
        self.n_epoch += self.n_epoch_each_update
        if self.n_epoch % self.save_each_n_epoch == 0:
            self.save()

    def model_path(self):
        return 'output/mappo/{}'.format(self.class_initializing_time)

    def save(self, suffix=''):
        if not os.path.exists('output/mappo/{}'.format(self.class_initializing_time)):
            os.makedirs('output/mappo/{}'.format(self.class_initializing_time))
        model_path = 'output/mappo/{}/cell_control_graph_ppo_agent{}.pt'.format(self.class_initializing_time, suffix)
        torch.save({
                'encoder': self.encoder.state_dict(),
                'policy_layers': self.policy_layers.state_dict(),
                'value_layers': self.value_layers.state_dict(),
                'optim': self.optim.state_dict(),
        }, model_path)

    def load(self, model_path):
        checkpoint = torch.load(model_path, map_location='cpu')
        self.encoder.load_state_dict(checkpoint['encoder'])
        self.policy_layers.load_state_dict(checkpoint['policy_layers'])
        self.value_layers.load_state_dict(checkpoint['value_layers'])
        self.optim.load_state_dict(checkpoint['optim'])

def training(port):
    eval_mode = False

    # ---- train GraphREINFORCEAgent ----
    # hyper-parameters
    device = 'cuda:0'
    max_training_timesteps = 600
    # criteria
    criteria = RunningCriteria(['saving_rate'], [1, 10, 100, 1000])
    # trajectory storage
    storage = TrajectoryStorage('training_trajectories')

    # environment
    interface = ConserveEnv(port=port, job="energy_saving_training", store_keep=False)
    env = InterfaceToSimulator(interface=interface)

    state, state_info = env.get_state()
    agent = GraphMAPPOAgent(state, selected_node_type='cell', data_key='feature',
                            n_episode_length=1, n_reward=1,
                            device=device)

    time_step = 0
    i_episode = 0
    rt = RemainingTime(n_iter= max_training_timesteps + 1)
    # training loop
    while time_step <= max_training_timesteps:
        rt.start_each_iter()
        # ---- reset
        # reset
        # _t = time.time()
        state, state_info = env.get_state()
        # print('state = env.get_state()', time.time()-_t)

        # ---- step to done
        action, action_logprob, state_value = agent.sample_action(state.to(device))
        action = action.cpu().numpy()
        agent.buffer.states.append(state)
        agent.buffer.values.append(state_value.cpu().numpy())
        agent.buffer.actions.append(action)
        agent.buffer.logprobs.append(action_logprob.cpu().numpy())

        # _t = time.time()
        result_info, action_info = env.sim_action({'cell_activate_status': action})
        reward = result_info['criteria']['power_save_ratio']
        storage.store_transition({
            'state': state_info,
            'action': action_info,
            'reward': reward
        })
        # print('state = env.sim_action', time.time()-_t)

        print('i_episode', i_episode, 'time_step', time_step, 'reward', reward)
        agent.buffer.rewards.append(reward * 10.)
        agent.buffer.dones.append(True)
        time_step += 1

        # update PPO agent
        agent.update()

        print('i_episode', i_episode, 'time_step', time_step)
        criteria.add(
            ['saving_rate'],
            [result_info['criteria']['power_save_ratio']])
        print('---- running_power_save_ratio ----', criteria.eval())

        # saving
        if time_step > 0 and time_step % 10 == 0:
            agent.save(suffix='_{}'.format(time_step))
            criteria.save(agent.model_path(), 'overall_criteria_{}'.format(time_step))

        i_episode += 1
        rt.end_each_iter()

def eval(port):
    eval_mode = True

    # ---- train GraphREINFORCEAgent ----
    # hyper-parameters
    device = 'cuda:0'
    # trajectory storage
    storage = TrajectoryStorage('evaluation_trajectories')

    # environment
    interface = ConserveEnv(port=port, job="energy_saving_eval", store_keep=True)
    interface1 = ConserveEnv(port=port, job="energy_saving_eval_temp", store_keep=False)
    env = InterfaceToSimulator(interface=interface)
    env1 = InterfaceToSimulator(interface=interface1)

    env1.start = start_time
    state, state_info = env1.get_state()
    agent = GraphMAPPOAgent(state, selected_node_type='cell', data_key='feature',
                            n_episode_length=1, n_reward=1,
                            device=device)
    agent.load('output/mappo/2023-06-20_14:31:16/cell_control_graph_ppo_agent_600.pt') # output/mappo/2023-05-13_09:18:13/cell_control_graph_ppo_agent_3000.pt

    time_step = 0
    i_episode = 0
    iterval = 30
    rt = RemainingTime(n_iter= (final_time - start_time) / iterval + 1)
    # training loop
    while True:
        rt.start_each_iter()
        # ---- reset
        # reset
        # _t = time.time()
        env.start = start_time + iterval * i_episode
        env1.start = start_time + iterval * i_episode
        print('---- time', env.start)
        if env.start >= final_time:
            break
        state, state_info = env1.get_state()
        # print('state = env.get_state()', time.time()-_t)

        env.cell_power_coef = env1.cell_power_coef
        env.capacity = env1.capacity
        env.user_demand = env1.user_demand
        env.bigraph_user_cell = env1.bigraph_user_cell
        env.user_id_to_kid = env1.user_id_to_kid
        env.bs_id_to_kid = env1.bs_id_to_kid

        # ---- step to done
        action, action_logprob, state_value = agent.sample_action(state.to(device))
        action = action.cpu().numpy()

        # _t = time.time()
        result_info, action_info = env.sim_action({'cell_activate_status': action})
        reward = result_info['criteria']['power_save_ratio']
        storage.store_transition({
            'state': state_info,
            'action': action_info,
            'reward': reward
        })
        # print('state = env.sim_action', time.time()-_t)

        print('i_episode', i_episode, 'reward', reward)
        time_step += 1

        i_episode += 1
        rt.end_each_iter()
    print('---- end ----')

def random_trajectory():
    eval_mode = True
    port = 1262

    # ---- train GraphREINFORCEAgent ----
    # hyper-parameters
    device = 'cuda:0'
    # trajectory storage
    storage = TrajectoryStorage('random_trajectories')

    # environment
    interface = ConserveEnv(port=port, job="energy_saving_rand", store_keep=True)
    interface1 = ConserveEnv(port=port, job="energy_saving_rand_temp", store_keep=False)
    env = InterfaceToSimulator(interface=interface)
    env1 = InterfaceToSimulator(interface=interface1)

    time_step = 0
    i_episode = 0
    iterval = 30
    rt = RemainingTime(n_iter= (final_time - start_time) / iterval + 1)
    # training loop
    while True:
        rt.start_each_iter()
        # ---- reset
        # reset
        # _t = time.time()
        env.start = start_time + iterval * i_episode
        env1.start = start_time + iterval * i_episode
        print('---- time', env.start)
        if env.start >= final_time:
            break
        state, state_info = env1.get_state()
        # print('state = env.get_state()', time.time()-_t)

        env.cell_power_coef = env1.cell_power_coef
        env.capacity = env1.capacity
        env.user_demand = env1.user_demand
        env.bigraph_user_cell = env1.bigraph_user_cell
        env.user_id_to_kid = env1.user_id_to_kid
        env.bs_id_to_kid = env1.bs_id_to_kid

        # ---- step to done
        random_action = np.random.randint(low=0, high=2, size=state_info['cell_num'])

        # _t = time.time()
        result_info, action_info = env.sim_action({'cell_activate_status': random_action})
        reward = result_info['criteria']['power_save_ratio']
        storage.store_transition({
            'state': state_info,
            'action': action_info,
            'reward': reward
        })
        # print('state = env.sim_action', time.time()-_t)

        print('i_episode', i_episode, 'reward', reward)
        time_step += 1

        i_episode += 1
        rt.end_each_iter()
    print('---- end ----')

if __name__ == '__main__':
    # ./comm_docker -config fudan_test_100w_js_big.yml -job energy_saving_evaluation_23_5_18 -rl -listen localhost:1261
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", default='train', type=str)  # {"train", "eval"}
    parser.add_argument('--port', default=12000, type=int)
    args = parser.parse_args()

    if args.mode == 'train':
        training(port=args.port)
    elif args.mode == 'eval':
        eval(port=args.port)
    else:
        raise NotImplementedError
