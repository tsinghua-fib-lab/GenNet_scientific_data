import numpy as np
import torch
import dgl
import dgl.nn as dglnn
import torch.nn as nn
import torch.nn.functional as F

class GraphEncoder(nn.Module):
    def __init__(self, in_feats, hid_feats, out_feats, n_layer, rel_names, node_names, num_heads=3, device='cuda:0'):
        super().__init__()
        self.in_feats = in_feats
        self.hid_feats = hid_feats
        self.out_feats = out_feats
        self.n_layer = n_layer
        self.num_heads = num_heads
        self.device = device

        assert self.n_layer >= 1
        n_input_each_layer = [None] + [self.hid_feats * self.num_heads for i in range(self.n_layer-1)]
        n_output_each_layer = [self.hid_feats for i in range(self.n_layer)]
        # 实例化HeteroGraphConv，in_feats是输入特征的维度，out_feats是输出特征的维度，aggregate是聚合函数的类型
        self.conv_layers = nn.ModuleList(
            [dglnn.HeteroGraphConv(
                {rel: dglnn.GATv2Conv(in_feats[i], n_output_each_layer[0], num_heads)
                 for i, rel in enumerate(rel_names)},
                aggregate='sum')])
        self.conv_layers.extend(
            [dglnn.HeteroGraphConv(
                {rel: dglnn.GATv2Conv(n_input_each_layer[i], n_output_each_layer[i], num_heads)
                 for rel in rel_names},
                aggregate='sum')
             for i in range(1, self.n_layer)])
        self.fc = dglnn.HeteroLinear({node: hid_feats * num_heads for node in node_names},
                                     self.out_feats)

        self._init_parameters()
        self.to(self.device)

    def _init_parameters(self):
        for cov_layer in self.conv_layers:
            for conv_param in cov_layer.mods.values():
                conv_param.reset_parameters()
        for lin in self.fc.linears.values():
            torch.nn.init.xavier_uniform_(lin.weight)

    def forward(self, graph, data_key='feature'):
        data_dict = {ntype: graph.nodes[ntype].data[data_key] for ntype in graph.ntypes}
        h = data_dict

        for conv_layer in self.conv_layers:
            h = conv_layer(graph, h)
            h = {k: (F.relu(v)).view(-1, self.hid_feats * self.num_heads) for k, v in h.items()}
        h = self.fc(h)

        return h

def create_from_heterogeneous_graph(hetero_graph, data_key='feature', n_hidden=8, n_out=32, n_head=3, n_layer=2, device='cuda:0'):
    node_types = hetero_graph.ntypes
    assert np.array([len(hetero_graph.nodes[node_type].data[data_key].shape)==2 for node_type in node_types]).all()
    node_dims = {node_type: hetero_graph.nodes[node_type].data[data_key].shape[-1] for node_type in node_types}

    canonical_etypes = hetero_graph.canonical_etypes
    n_inputs = []
    rel_names = []
    for ce_type in canonical_etypes:
        rel_names.append(ce_type[1])
        n_inputs.append((node_dims[ce_type[0]], node_dims[ce_type[2]]))
    model = GraphEncoder(in_feats=n_inputs,
                         hid_feats=n_hidden,
                         out_feats=n_out,
                         n_layer=n_layer,
                         rel_names=rel_names,
                         node_names=node_types,
                         num_heads=n_head,
                         device=device
                         )
    return model


if __name__ == '__main__':

    pass


